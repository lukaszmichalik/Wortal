package com.okta.Wortal

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class WortalApplicationTests {

	@Test
	fun contextLoads() {
	}

}
