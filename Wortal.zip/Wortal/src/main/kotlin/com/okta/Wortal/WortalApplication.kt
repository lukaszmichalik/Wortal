package com.okta.Wortal

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class WortalApplication

fun main(args: Array<String>) {
	runApplication<WortalApplication>(*args)
}
